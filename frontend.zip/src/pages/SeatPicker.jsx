// src/pages/SeatPicker.jsx
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Button } from "../components/ui/Button/Button";
import { seatService } from "../services/api";
import "./SeatPicker.css";

export default function SeatPicker() {
  const { showtimeId } = useParams();
  const [seats, setSeats] = useState([]);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchSeats = async () => {
      try {
        setLoading(true);
        // Call the backend endpoint: GET /api/seats/showtime/{showtimeId}/available
        const res = await seatService.getSeatsByShowtime(showtimeId);
        setSeats(res.data); // Expecting an array of seat objects
      } catch (err) {
        console.error("Failed to fetch seats:", err);
        setError("Failed to load seats. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchSeats();
  }, [showtimeId]);

  const toggleSeat = (seatId) => {
    setSelected((prev) =>
      prev.includes(seatId)
        ? prev.filter((id) => id !== seatId)
        : [...prev, seatId]
    );
  };

  if (loading) {
    return <div className="text-center p-4">Loading seats...</div>;
  }

  if (error) {
    return <div className="text-red-500 p-4 text-center">{error}</div>;
  }

  return (
    <div className="seat-picker-container">
      <h2>Select Your Seats</h2>
      <p>Showtime ID: {showtimeId}</p>
      <div className="seats-grid">
        {seats.map((seat) => (
          <button
            key={seat.id}
            className={`seat ${selected.includes(seat.id) ? "selected" : ""}`}
            onClick={() => toggleSeat(seat.id)}
            disabled={!seat.available}
          >
            {seat.rowLetter}
            {seat.seatNumber}
          </button>
        ))}
      </div>
      <div className="selected-summary">
        <p>
          Selected Seats: {selected.length ? selected.join(", ") : "None"}
        </p>
        <Button disabled={!selected.length}>Continue</Button>
      </div>
    </div>
  );
}
